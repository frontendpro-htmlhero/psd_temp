






---------------------------------free-psd-templates.com-----------------------------------








Hello! Thanks a lot for downloading the website template, I hope it will be of service to you.

----------------------------------------------------------------------------------

You can easily change texts, content, images, objects and color palette.
The PSD file is very well organised, with color coded groups and layers named appropriately


<<<<<<<<<<<<<<<<<<<<<<Free fonts used in design:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

NEXT ART
https://www.dafont.com/next-art.font

Louis George Cafe
https://www.dafont.com/louis-george-caf.font

Red Velvet
https://www.dafont.com/red-velvet2.font

Brushwell
https://www.dafont.com/brushwell.font

<<<<<<<<<<<<<<<<<<<<<< Credits: >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

https://www.pexels.com/photo/pink-flowers-photograph-1083822/
https://www.pexels.com/photo/photo-of-red-peonies-painting-1005711/
https://www.pexels.com/photo/woman-standing-beside-grass-1998880/
https://www.pexels.com/photo/photo-of-couple-hugging-each-other-3512506/
https://www.pexels.com/photo/man-wearing-grey-shirt-hugging-woman-outside-ner-crops-3373366/
https://www.pexels.com/photo/photo-of-people-standing-in-the-shore-3057923/
https://www.pexels.com/photo/photo-of-couple-holding-hands-on-the-road-2828549/
https://www.pexels.com/photo/man-and-woman-hugging-while-standing-on-rock-3617553/
https://www.pexels.com/photo/photo-of-couple-walking-on-road-3617576/
https://www.pexels.com/photo/photo-of-a-man-lifting-woman-near-body-of-water-2808658/
https://www.pexels.com/photo/photo-of-couple-standing-beside-tree-3369228/
https://www.pexels.com/photo/photo-of-couple-sitting-on-stairs-3271024/
https://www.pexels.com/photo/man-holding-pregnant-woman-s-baby-bump-2997781/
https://www.pexels.com/photo/photo-of-people-running-on-road-3617519/
https://www.pexels.com/photo/man-and-woman-on-bathtub-3767403/
https://www.pexels.com/photo/photo-of-woman-hugging-man-3692760/

----------------------------------------------------------------------------------


Our team thanks you again for downloading this website template.

We are always happy to help you. 





---------------------------------free-psd-templates.com-----------------------------------
